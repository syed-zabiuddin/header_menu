export const menuItems = [
  {
    title: 'Home',
    url: '/',
  },
  {
    title: 'Services',
    url: '/services',
    icon: 'caret',
    submenu: [
      'Plan Brochure Provider',
      'Search Personal Health Profile Request',
      'Summary of Benefits and Coverage',
      'ID CARD REQUEST FORM',
      'Frequently Asked Questions',
    ],
  },
  {
    title: 'Members',
    url: '/members',
    icon: 'caret',
    submenu: ['News', 'Member Login'],
  },
  {
    title: 'Transparency',
    url: '/transparency',
    icon: 'caret',
    submenu: [
      'Average Cost of Common Procedures',
      'Average Cost of Common Medications',
      'Personal Health Profile Request',
      'Diabetes Program',
      'Population Health and Wellness',
      'Privacy & Security',
    ],
  },
  {
    title: 'About',
    url: '/about',
    icon: 'caret',
    submenu: ['Privacy and Security', 'AJAC Info'],
  },
  {
    title: 'Contact',
    url: '/contact',
  },
  {
    title: 'English',
    url: '/english',
    icon: 'caret',
    submenu: ['Español'],
  },
];
