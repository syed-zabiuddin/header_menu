import Navbar from './Navbar';
import React from 'react';
const Header = () => {
  return (
    <header>
      <div className="nav-area">
        <a className="logo" href="/">
          <img
            src="https://i.ibb.co/gT13RnH/Logo-Main-Page-copy-copy.png"
            alt="Logo-Main-Page-copy-copy"
            border="0"
          />
        </a>
        <Navbar />
        <img
          className="lang"
          src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAALCAMAAABBPP0LAAAAmVBMVEViZsViZMJiYrf9gnL8eWrlYkjgYkjZYkj8/PujwPybvPz4+PetraBEgfo+fvo3efkydfkqcvj8Y2T8UlL8Q0P8MzP9k4Hz8/Lu7u4DdPj9/VrKysI9fPoDc/EAZ7z7IiLHYkjp6ekCcOTk5OIASbfY/v21takAJrT5Dg6sYkjc3Nn94t2RkYD+y8KeYkjs/v7l5fz0dF22YkjWvcOLAAAAgElEQVR4AR2KNULFQBgGZ5J13KGGKvc/Cw1uPe62eb9+Jr1EUBFHSgxxjP2Eca6AfUSfVlUfBvm1Ui1bqafctqMndNkXpb01h5TLx4b6TIXgwOCHfjv+/Pz+5vPRw7txGWT2h6yO0/GaYltIp5PT1dEpLNPL/SdWjYjAAZtvRPgHJX4Xio+DSrkAAAAASUVORK5CYII="
          alt="English"
          width="16"
          height="11"
        />
      </div>
    </header>
  );
};

export default Header;
