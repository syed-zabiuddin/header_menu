import React from 'react';
import './style.css';

import Header from './components/Header';

const App = () => {
  return (
    <div>
      <Header />
    </div>
  );
};

export default App;
