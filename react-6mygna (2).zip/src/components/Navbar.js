import React from 'react';
import { menuItems } from '../menuItems';
const Navbar = () => {
  return (
    <nav>
      <ul className="menus">
        {menuItems.map((menu, index) => {
          return (
            <li className="menu-items" key={index}>
              <a href={menu.url}>
                {menu.title}
                {menu.icon && <span className={menu.icon}></span>}
              </a>
              {menu.submenu && (
                <ul className="submenus">
                  {menu.submenu.map((submenu, index) => {
                    return (
                      <li className="menu-items" key={index}>
                        <a href="#">{submenu}</a>
                      </li>
                    );
                  })}
                </ul>
              )}
            </li>
          );
        })}
      </ul>
    </nav>
  );
};

export default Navbar;
